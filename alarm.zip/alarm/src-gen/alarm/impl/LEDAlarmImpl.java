/**
 */
package alarm.impl;

import alarm.Actuator;
import alarm.LEDAlarm;
import alarm.alarmPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>LED Alarm</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link alarm.impl.LEDAlarmImpl#getLED <em>LED</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class LEDAlarmImpl extends AlarmImpl implements LEDAlarm {
	/**
	 * The cached value of the '{@link #getLED() <em>LED</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLED()
	 * @generated
	 * @ordered
	 */
	protected Actuator led;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected LEDAlarmImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return alarmPackage.Literals.LED_ALARM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Actuator getLED() {
		return led;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetLED(Actuator newLED, NotificationChain msgs) {
		Actuator oldLED = led;
		led = newLED;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, alarmPackage.LED_ALARM__LED,
					oldLED, newLED);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLED(Actuator newLED) {
		if (newLED != led) {
			NotificationChain msgs = null;
			if (led != null)
				msgs = ((InternalEObject) led).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - alarmPackage.LED_ALARM__LED, null, msgs);
			if (newLED != null)
				msgs = ((InternalEObject) newLED).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - alarmPackage.LED_ALARM__LED, null, msgs);
			msgs = basicSetLED(newLED, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, alarmPackage.LED_ALARM__LED, newLED, newLED));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case alarmPackage.LED_ALARM__LED:
			return basicSetLED(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case alarmPackage.LED_ALARM__LED:
			return getLED();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case alarmPackage.LED_ALARM__LED:
			setLED((Actuator) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case alarmPackage.LED_ALARM__LED:
			setLED((Actuator) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case alarmPackage.LED_ALARM__LED:
			return led != null;
		}
		return super.eIsSet(featureID);
	}

} //LEDAlarmImpl
