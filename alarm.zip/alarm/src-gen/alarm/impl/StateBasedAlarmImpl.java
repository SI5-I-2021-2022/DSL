/**
 */
package alarm.impl;

import alarm.StateBasedAlarm;
import alarm.alarmPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>State Based Alarm</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class StateBasedAlarmImpl extends LEDAlarmImpl implements StateBasedAlarm {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected StateBasedAlarmImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return alarmPackage.Literals.STATE_BASED_ALARM;
	}

} //StateBasedAlarmImpl
