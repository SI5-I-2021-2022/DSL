/**
 */
package alarm.impl;

import alarm.DualCheckAlarm;
import alarm.Sensor;
import alarm.alarmPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Dual Check Alarm</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link alarm.impl.DualCheckAlarmImpl#getButton2 <em>Button2</em>}</li>
 * </ul>
 *
 * @generated
 */
public class DualCheckAlarmImpl extends BuzzerAlarmImpl implements DualCheckAlarm {
	/**
	 * The cached value of the '{@link #getButton2() <em>Button2</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getButton2()
	 * @generated
	 * @ordered
	 */
	protected Sensor button2;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected DualCheckAlarmImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return alarmPackage.Literals.DUAL_CHECK_ALARM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Sensor getButton2() {
		return button2;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetButton2(Sensor newButton2, NotificationChain msgs) {
		Sensor oldButton2 = button2;
		button2 = newButton2;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					alarmPackage.DUAL_CHECK_ALARM__BUTTON2, oldButton2, newButton2);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setButton2(Sensor newButton2) {
		if (newButton2 != button2) {
			NotificationChain msgs = null;
			if (button2 != null)
				msgs = ((InternalEObject) button2).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - alarmPackage.DUAL_CHECK_ALARM__BUTTON2, null, msgs);
			if (newButton2 != null)
				msgs = ((InternalEObject) newButton2).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - alarmPackage.DUAL_CHECK_ALARM__BUTTON2, null, msgs);
			msgs = basicSetButton2(newButton2, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, alarmPackage.DUAL_CHECK_ALARM__BUTTON2, newButton2,
					newButton2));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case alarmPackage.DUAL_CHECK_ALARM__BUTTON2:
			return basicSetButton2(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case alarmPackage.DUAL_CHECK_ALARM__BUTTON2:
			return getButton2();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case alarmPackage.DUAL_CHECK_ALARM__BUTTON2:
			setButton2((Sensor) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case alarmPackage.DUAL_CHECK_ALARM__BUTTON2:
			setButton2((Sensor) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case alarmPackage.DUAL_CHECK_ALARM__BUTTON2:
			return button2 != null;
		}
		return super.eIsSet(featureID);
	}

} //DualCheckAlarmImpl
