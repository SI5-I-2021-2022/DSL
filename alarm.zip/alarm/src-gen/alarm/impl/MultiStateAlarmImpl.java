/**
 */
package alarm.impl;

import alarm.Actuator;
import alarm.LEDAlarm;
import alarm.MultiStateAlarm;
import alarm.alarmPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Multi State Alarm</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link alarm.impl.MultiStateAlarmImpl#getLED <em>LED</em>}</li>
 * </ul>
 *
 * @generated
 */
public class MultiStateAlarmImpl extends BuzzerAlarmImpl implements MultiStateAlarm {
	/**
	 * The cached value of the '{@link #getLED() <em>LED</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getLED()
	 * @generated
	 * @ordered
	 */
	protected Actuator led;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected MultiStateAlarmImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return alarmPackage.Literals.MULTI_STATE_ALARM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Actuator getLED() {
		return led;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetLED(Actuator newLED, NotificationChain msgs) {
		Actuator oldLED = led;
		led = newLED;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					alarmPackage.MULTI_STATE_ALARM__LED, oldLED, newLED);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setLED(Actuator newLED) {
		if (newLED != led) {
			NotificationChain msgs = null;
			if (led != null)
				msgs = ((InternalEObject) led).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - alarmPackage.MULTI_STATE_ALARM__LED, null, msgs);
			if (newLED != null)
				msgs = ((InternalEObject) newLED).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - alarmPackage.MULTI_STATE_ALARM__LED, null, msgs);
			msgs = basicSetLED(newLED, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, alarmPackage.MULTI_STATE_ALARM__LED, newLED, newLED));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case alarmPackage.MULTI_STATE_ALARM__LED:
			return basicSetLED(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case alarmPackage.MULTI_STATE_ALARM__LED:
			return getLED();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case alarmPackage.MULTI_STATE_ALARM__LED:
			setLED((Actuator) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case alarmPackage.MULTI_STATE_ALARM__LED:
			setLED((Actuator) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case alarmPackage.MULTI_STATE_ALARM__LED:
			return led != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eBaseStructuralFeatureID(int derivedFeatureID, Class<?> baseClass) {
		if (baseClass == LEDAlarm.class) {
			switch (derivedFeatureID) {
			case alarmPackage.MULTI_STATE_ALARM__LED:
				return alarmPackage.LED_ALARM__LED;
			default:
				return -1;
			}
		}
		return super.eBaseStructuralFeatureID(derivedFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eDerivedStructuralFeatureID(int baseFeatureID, Class<?> baseClass) {
		if (baseClass == LEDAlarm.class) {
			switch (baseFeatureID) {
			case alarmPackage.LED_ALARM__LED:
				return alarmPackage.MULTI_STATE_ALARM__LED;
			default:
				return -1;
			}
		}
		return super.eDerivedStructuralFeatureID(baseFeatureID, baseClass);
	}

} //MultiStateAlarmImpl
