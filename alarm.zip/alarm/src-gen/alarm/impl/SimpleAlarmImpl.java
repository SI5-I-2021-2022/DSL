/**
 */
package alarm.impl;

import alarm.Actuator;
import alarm.BuzzerAlarm;
import alarm.SimpleAlarm;
import alarm.alarmPackage;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Simple Alarm</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link alarm.impl.SimpleAlarmImpl#getBuzzer <em>Buzzer</em>}</li>
 * </ul>
 *
 * @generated
 */
public class SimpleAlarmImpl extends LEDAlarmImpl implements SimpleAlarm {
	/**
	 * The cached value of the '{@link #getBuzzer() <em>Buzzer</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBuzzer()
	 * @generated
	 * @ordered
	 */
	protected Actuator buzzer;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SimpleAlarmImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return alarmPackage.Literals.SIMPLE_ALARM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Actuator getBuzzer() {
		return buzzer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetBuzzer(Actuator newBuzzer, NotificationChain msgs) {
		Actuator oldBuzzer = buzzer;
		buzzer = newBuzzer;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET,
					alarmPackage.SIMPLE_ALARM__BUZZER, oldBuzzer, newBuzzer);
			if (msgs == null)
				msgs = notification;
			else
				msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setBuzzer(Actuator newBuzzer) {
		if (newBuzzer != buzzer) {
			NotificationChain msgs = null;
			if (buzzer != null)
				msgs = ((InternalEObject) buzzer).eInverseRemove(this,
						EOPPOSITE_FEATURE_BASE - alarmPackage.SIMPLE_ALARM__BUZZER, null, msgs);
			if (newBuzzer != null)
				msgs = ((InternalEObject) newBuzzer).eInverseAdd(this,
						EOPPOSITE_FEATURE_BASE - alarmPackage.SIMPLE_ALARM__BUZZER, null, msgs);
			msgs = basicSetBuzzer(newBuzzer, msgs);
			if (msgs != null)
				msgs.dispatch();
		} else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, alarmPackage.SIMPLE_ALARM__BUZZER, newBuzzer,
					newBuzzer));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
		case alarmPackage.SIMPLE_ALARM__BUZZER:
			return basicSetBuzzer(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case alarmPackage.SIMPLE_ALARM__BUZZER:
			return getBuzzer();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case alarmPackage.SIMPLE_ALARM__BUZZER:
			setBuzzer((Actuator) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case alarmPackage.SIMPLE_ALARM__BUZZER:
			setBuzzer((Actuator) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case alarmPackage.SIMPLE_ALARM__BUZZER:
			return buzzer != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eBaseStructuralFeatureID(int derivedFeatureID, Class<?> baseClass) {
		if (baseClass == BuzzerAlarm.class) {
			switch (derivedFeatureID) {
			case alarmPackage.SIMPLE_ALARM__BUZZER:
				return alarmPackage.BUZZER_ALARM__BUZZER;
			default:
				return -1;
			}
		}
		return super.eBaseStructuralFeatureID(derivedFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eDerivedStructuralFeatureID(int baseFeatureID, Class<?> baseClass) {
		if (baseClass == BuzzerAlarm.class) {
			switch (baseFeatureID) {
			case alarmPackage.BUZZER_ALARM__BUZZER:
				return alarmPackage.SIMPLE_ALARM__BUZZER;
			default:
				return -1;
			}
		}
		return super.eDerivedStructuralFeatureID(baseFeatureID, baseClass);
	}

} //SimpleAlarmImpl
