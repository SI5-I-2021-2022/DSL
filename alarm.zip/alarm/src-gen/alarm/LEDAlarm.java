/**
 */
package alarm;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>LED Alarm</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link alarm.LEDAlarm#getLED <em>LED</em>}</li>
 * </ul>
 *
 * @see alarm.alarmPackage#getLEDAlarm()
 * @model abstract="true"
 * @generated
 */
public interface LEDAlarm extends Alarm {
	/**
	 * Returns the value of the '<em><b>LED</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>LED</em>' containment reference.
	 * @see #setLED(Actuator)
	 * @see alarm.alarmPackage#getLEDAlarm_LED()
	 * @model containment="true" required="true"
	 * @generated
	 */
	Actuator getLED();

	/**
	 * Sets the value of the '{@link alarm.LEDAlarm#getLED <em>LED</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>LED</em>' containment reference.
	 * @see #getLED()
	 * @generated
	 */
	void setLED(Actuator value);

} // LEDAlarm
