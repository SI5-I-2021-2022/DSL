/**
 */
package alarm;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>State Based Alarm</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see alarm.alarmPackage#getStateBasedAlarm()
 * @model
 * @generated
 */
public interface StateBasedAlarm extends LEDAlarm {
} // StateBasedAlarm
